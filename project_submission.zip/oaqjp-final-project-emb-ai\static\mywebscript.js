/**
 * Sends the text input to the Flask /emotionDetector endpoint
 * and displays the result on the page.
 */
function RunSentimentAnalysis() {
    const textToAnalyse = document.getElementById('textToAnalyse').value;
    const outputDiv = document.getElementById('system-output');

    if (!textToAnalyse.trim()) {
        outputDiv.innerHTML = '<span style="color:#e96c75;">Please enter some text before running the analysis.</span>';
        return;
    }

    outputDiv.innerHTML = '<span class="loading">Analysing emotions...</span>';

    const xhttp = new XMLHttpRequest();
    xhttp.onreadystatechange = function () {
        if (this.readyState === 4 && this.status === 200) {
            outputDiv.innerHTML = this.responseText;
        } else if (this.readyState === 4) {
            outputDiv.innerHTML = '<span style="color:#e96c75;">Error connecting to the server. Please try again.</span>';
        }
    };
    xhttp.open(
        'GET',
        '/emotionDetector?textToAnalyse=' + encodeURIComponent(textToAnalyse),
        true
    );
    xhttp.send();
}
